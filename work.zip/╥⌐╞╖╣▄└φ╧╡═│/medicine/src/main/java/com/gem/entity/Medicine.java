package com.gem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * 药品实体类
 */
@Data
@TableName("tbl_medicine")
public class Medicine {
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getFordisease() {
        return fordisease;
    }

    public void setFordisease(String fordisease) {
        this.fordisease = fordisease;
    }

    public String getFactory() {
        return factory;
    }

    public void setFactory(String factory) {
        this.factory = factory;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    @TableId(type = IdType.AUTO)
    private Long id;
    private String name;
    private String msg;
    private String fordisease;
    private String factory;

    //逻辑删除字段
    @TableLogic
    private int deleted;
}

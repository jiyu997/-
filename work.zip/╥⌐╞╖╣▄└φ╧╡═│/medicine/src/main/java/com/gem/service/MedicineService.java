package com.gem.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gem.entity.Medicine;



public interface MedicineService extends IService<Medicine> {
}

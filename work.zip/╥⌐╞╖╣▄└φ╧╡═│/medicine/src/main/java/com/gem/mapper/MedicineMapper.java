package com.gem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gem.entity.Medicine;

public interface MedicineMapper extends BaseMapper<Medicine> {
}
